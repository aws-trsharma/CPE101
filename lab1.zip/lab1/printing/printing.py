def print_examples():
   n = 2
   m = 4
   f = 42.7
   # place the print calls specified in the lab description below here
   print("Entered print_examples function. \n")
   print("n:", n)
   n = 99
   print("n:", n, "\tm:", m)
   print("f:", f)

if __name__ == '__main__':
   print_examples()
