#

# This is a header block example for lab 1.
#
# You will need to supply the following information.
#
# Name: Tushar Sharma
# Instructor: Julie Workman
# Section:CPE 101-07
#
print("Hello, Tushar.")
